/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "prescribedMotionDisplacementPointPatchVectorField.H"
#include "pointPatchFields.H"
#include "addToRunTimeSelectionTable.H"
#include "Time.H"
#include "polyMesh.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

namespace Foam
{

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

prescribedMotionDisplacementPointPatchVectorField::
prescribedMotionDisplacementPointPatchVectorField
(
    const pointPatch& p,
    const DimensionedField<vector, pointMesh>& iF
)
:
    fixedValuePointPatchField<vector>(p, iF),
    N_ (1),                    //default value is 1.
    transAmplitude_(N_, 0.0),
    angularAmplitude_(N_, 0.0),
    transPhase_(N_, 0.0),
    angularPhase_(N_, 0.0),
    omega_(N_, 0.0),
    transAxis_(vector::zero),
    rotatAxis_(vector::zero),
    origin_(vector::zero),
    angle0_(0.0),
    rampTime_(0.0),
    p0_(p.localPoints())
{}


prescribedMotionDisplacementPointPatchVectorField::
prescribedMotionDisplacementPointPatchVectorField
(
    const pointPatch& p,
    const DimensionedField<vector, pointMesh>& iF,
    const dictionary& dict
)
:
    fixedValuePointPatchField<vector>(p, iF, dict),
    N_(readScalar(dict.lookup("N"))),
    transAmplitude_("transAmplitude", dict, N_),
    angularAmplitude_("angularAmplitude", dict, N_),
    transPhase_("transPhase", dict, N_),
    angularPhase_("angularPhase", dict, N_),    
    omega_("omega", dict, N_),
    transAxis_(dict.lookup("transAxis")),
    rotatAxis_(dict.lookup("rotatAxis")),
    origin_(dict.lookup("origin")),
    angle0_(readScalar(dict.lookup("angle0"))),
    rampTime_(readScalar(dict.lookup("rampTime")))   
{
    if (!dict.found("value"))
    {
        updateCoeffs();
    }
    if (dict.found("p0"))
    {
        p0_ = vectorField("p0", dict , p.size());
    }
    else
    {
        p0_ = p.localPoints();
    }
}


prescribedMotionDisplacementPointPatchVectorField::
prescribedMotionDisplacementPointPatchVectorField
(
    const prescribedMotionDisplacementPointPatchVectorField& ptf,
    const pointPatch& p,
    const DimensionedField<vector, pointMesh>& iF,
    const pointPatchFieldMapper& mapper
)
:
    fixedValuePointPatchField<vector>(ptf, p, iF, mapper),
    N_(ptf.N_),
    transAmplitude_(ptf.transAmplitude_),
    angularAmplitude_(ptf.angularAmplitude_),
    transPhase_(ptf.transPhase_),
    angularPhase_(ptf.angularPhase_),
    omega_(ptf.omega_),
    transAxis_(ptf.transAxis_),
    rotatAxis_(ptf.rotatAxis_),
    origin_(ptf.origin_),
    angle0_(ptf.angle0_),
    rampTime_(ptf.rampTime_),
    p0_(ptf.p0_, mapper)
{}


prescribedMotionDisplacementPointPatchVectorField::
prescribedMotionDisplacementPointPatchVectorField
(
    const prescribedMotionDisplacementPointPatchVectorField& ptf,
    const DimensionedField<vector, pointMesh>& iF
)
:
    fixedValuePointPatchField<vector>(ptf, iF),
    N_(ptf.N_),
    transAmplitude_(ptf.transAmplitude_),
    angularAmplitude_(ptf.angularAmplitude_),
    transPhase_(ptf.transPhase_),
    angularPhase_(ptf.angularPhase_),
    omega_(ptf.omega_),
    transAxis_(ptf.transAxis_),
    rotatAxis_(ptf.rotatAxis_),
    origin_(ptf.origin_),
    angle0_(ptf.angle0_),
    rampTime_(ptf.rampTime_),
    p0_(ptf.p0_)

{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

void prescribedMotionDisplacementPointPatchVectorField::autoMap
(
    const pointPatchFieldMapper& m
)
{
    fixedValuePointPatchField<vector>::autoMap(m);

    p0_.autoMap(m);
}


void prescribedMotionDisplacementPointPatchVectorField::rmap
(
    const pointPatchField<vector>& ptf,
    const labelList& addr
)
{
    const prescribedMotionDisplacementPointPatchVectorField& aODptf =
        refCast<const prescribedMotionDisplacementPointPatchVectorField>(ptf);

    fixedValuePointPatchField<vector>::rmap(aODptf, addr);

    p0_.rmap(aODptf.p0_, addr);
}

void prescribedMotionDisplacementPointPatchVectorField::updateCoeffs()
{
    if (this->updated())
    {
        return;
    }

    const polyMesh& mesh = this->dimensionedInternalField().mesh()();
    const Time& t = mesh.time();

    vector transAxisHat = transAxis_/mag(transAxis_);
    vector rotatAxisHat = rotatAxis_/mag(rotatAxis_);
    vectorField p0Rel(p0_ - origin_);
    vector transDisp (vector::zero);
    scalar angle = angle0_;
    
    if (t.value()>=rampTime_)
    {

    forAll (transAmplitude_, index)
    {
        transDisp=transDisp+transAxisHat*transAmplitude_[index]*cos(omega_[index]*t.value()+transPhase_[index]);
        angle=angle+angularAmplitude_[index]*cos(omega_[index]*t.value()+angularPhase_[index]);
    }
    
    }


    vectorField::operator=
    (
        p0Rel*(cos(angle) - 1)
      + (rotatAxisHat ^ p0Rel*sin(angle))
      + (rotatAxisHat & p0Rel)*(1 - cos(angle))*rotatAxisHat
      + transDisp
    );

    fixedValuePointPatchField<vector>::updateCoeffs();
}


void prescribedMotionDisplacementPointPatchVectorField::write(Ostream& os) const
{
    pointPatchField<vector>::write(os);
    os.writeKeyword("N")
        << N_ << token::END_STATEMENT << nl;
    transAmplitude_.writeEntry("transAmplitude", os);
    angularAmplitude_.writeEntry("angularAmplitude", os);
    transPhase_.writeEntry("transPhase", os);
    angularPhase_.writeEntry("angularPhase", os);
    omega_.writeEntry("omega", os);
    os.writeKeyword("transAxis")
        << transAxis_ << token::END_STATEMENT << nl;
    os.writeKeyword("rotatAxis")
        << rotatAxis_ << token::END_STATEMENT << nl;
    os.writeKeyword("origin")
        << origin_ << token::END_STATEMENT << nl;
    os.writeKeyword("angle0")
        << angle0_ << token::END_STATEMENT << nl;
    os.writeKeyword("rampTime")
        << rampTime_ << token::END_STATEMENT << nl;
    p0_.writeEntry("p0", os);
    writeEntry("value", os);
}


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

makePointPatchTypeField
(
    pointPatchVectorField,
    prescribedMotionDisplacementPointPatchVectorField
);

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

} // End namespace Foam

// ************************************************************************* //
